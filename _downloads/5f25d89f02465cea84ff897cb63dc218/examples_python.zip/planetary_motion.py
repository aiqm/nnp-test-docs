"""
Use ASE to Simulate Planetary Motion
====================================

This tutorial shows how to use ASE to simulate planetary motion.
Although both
"""
import torch
import ase
import nnp
import pytest

def test_result():
    return

if __name__ == '__main__':
    pytest.main()
